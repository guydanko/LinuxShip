
#include "Ship.h"

void Ship::sailToNextPort() {
    if (!this->shipRoute.empty()) {
        this->shipRoute.pop_front();
    }
}

