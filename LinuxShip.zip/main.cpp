#include "Simulator.h"

int main() {
    Simulator sim("Travels");
   sim.run();
   exit(EXIT_SUCCESS);
}